package util;

public class Validaciones {

	public static final String NOMBRE = "[a-zA-Z��������������\\s]{2,10}";
	public static final String FECHA_NACIMIENTO = "((19|20)\\d\\d)-(0?[1-9]|1[012])";
	public static final String RUC = "(78)[0-9]{9}";
	public static final String TARGETA_CREDITO = "15-203-[0-9]{4}-[0-9]";
	public static final String CORREO = "(c.)[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@telefonica.pe";
	
	public static final String NOMBRE_EXTENSO = "[a-zA-Z��������������\\s]{0,20}";
	public static final String DNI = "(10)[0-9]{5}(9)";
	public static final String ESTADO_CIVIL = "[SCVDscvd]";
	public static final String CORREO_UPC = "(i)[0-9]{8}(@upc.edu.pe)";
	
}
