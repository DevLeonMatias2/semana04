package vista;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import util.Validaciones;

public class FrmSimulacro02 extends JFrame implements ActionListener {

	private JPanel contentPane;
	private static final long serialVersionUID = 1L;

	private JTextField txtNombre;
	private JTextField txtDNI;
	private JTextField txtEstado;
	private JTextField txtCorreo;
	private JButton btnRegistrar;
	
	public FrmSimulacro02() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 598, 472);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegistroDeCliente = new JLabel("Registro de alumno");
		lblRegistroDeCliente.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblRegistroDeCliente.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistroDeCliente.setBounds(25, 11, 547, 37);
		contentPane.add(lblRegistroDeCliente);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(111, 85, 143, 14);
		contentPane.add(lblNombre);
		
		JLabel lblDni = new JLabel("DNI");
		lblDni.setBounds(111, 159, 143, 14);
		contentPane.add(lblDni);
		
		JLabel lblRuc = new JLabel("Estado");
		lblRuc.setBounds(111, 233, 169, 14);
		contentPane.add(lblRuc);
		
		JLabel lblTargetaDeCrdito = new JLabel("Correo");
		lblTargetaDeCrdito.setBounds(111, 307, 143, 14);
		contentPane.add(lblTargetaDeCrdito);
		
		btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(this);
		btnRegistrar.setBounds(237, 376, 89, 23);
		contentPane.add(btnRegistrar);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(351, 82, 143, 20);
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);
		
		txtDNI = new JTextField();
		txtDNI.setBounds(351, 156, 143, 20);
		contentPane.add(txtDNI);
		txtDNI.setColumns(10);
		
		txtEstado = new JTextField();
		txtEstado.setBounds(351, 230, 143, 20);
		contentPane.add(txtEstado);
		txtEstado.setColumns(10);
		
		txtCorreo = new JTextField();
		txtCorreo.setBounds(351, 304, 143, 20);
		contentPane.add(txtCorreo);
		txtCorreo.setColumns(10);
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmSimulacro02 frame = new FrmSimulacro02();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}



	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnRegistrar) {
			actionPerformedBtnRegistrarJButton(e);
		}
	}
	protected void actionPerformedBtnRegistrarJButton(ActionEvent e) {
		String nom = txtNombre.getText().trim();
		String dni = txtDNI.getText().trim();
		String estado  = txtEstado.getText().trim();
		String cor = txtCorreo.getText().trim();
		
		if(nom.matches(Validaciones.NOMBRE_EXTENSO) == false) {
			mensaje("El nombre es de 0 a 20 caracteres");
		}else if(dni.matches(Validaciones.DNI) == false) {
			mensaje("El dni tiene formato 10XXXXX9");
		}else if(estado.matches(Validaciones.ESTADO_CIVIL) == false) {
			mensaje("El estado civil es S,C,V,D,s,c,v,d");
		}else if(cor.matches(Validaciones.CORREO_UPC) == false) {
			mensaje("El correo es de formato iXXXXXXX@upc.edu.pe");
		}else {
			mensaje("Se env�an los datos");
		}
		
	}
	
	public void mensaje(String msg) {
		JOptionPane.showMessageDialog(this, msg);
	}
}
