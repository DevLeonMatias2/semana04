package vista;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import util.Validaciones;


public class FrmSimulacro01 extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNombre;
	private JTextField txtFecha;
	private JTextField txtRuc;
	private JTextField txtTargeta;
	private JTextField txtCorreo;
	private JButton btnRegistrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmSimulacro01 frame = new FrmSimulacro01();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmSimulacro01() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 598, 508);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegistroDeCliente = new JLabel("Registro de cliente");
		lblRegistroDeCliente.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblRegistroDeCliente.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistroDeCliente.setBounds(25, 11, 547, 37);
		contentPane.add(lblRegistroDeCliente);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(111, 85, 143, 14);
		contentPane.add(lblNombre);
		
		JLabel lblDni = new JLabel("Fecha Nacimiento");
		lblDni.setBounds(111, 159, 143, 14);
		contentPane.add(lblDni);
		
		JLabel lblRuc = new JLabel("RUC");
		lblRuc.setBounds(111, 233, 169, 14);
		contentPane.add(lblRuc);
		
		JLabel lblTargetaDeCrdito = new JLabel("Targeta de cr\u00E9dito");
		lblTargetaDeCrdito.setBounds(111, 307, 143, 14);
		contentPane.add(lblTargetaDeCrdito);
		
		JLabel lblCorreo = new JLabel("Correo");
		lblCorreo.setBounds(111, 381, 46, 14);
		contentPane.add(lblCorreo);
		
		btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(this);
		btnRegistrar.setBounds(238, 420, 89, 23);
		contentPane.add(btnRegistrar);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(351, 82, 143, 20);
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);
		
		txtFecha = new JTextField();
		txtFecha.setBounds(351, 156, 143, 20);
		contentPane.add(txtFecha);
		txtFecha.setColumns(10);
		
		txtRuc = new JTextField();
		txtRuc.setBounds(351, 230, 143, 20);
		contentPane.add(txtRuc);
		txtRuc.setColumns(10);
		
		txtTargeta = new JTextField();
		txtTargeta.setBounds(351, 304, 143, 20);
		contentPane.add(txtTargeta);
		txtTargeta.setColumns(10);
		
		txtCorreo = new JTextField();
		txtCorreo.setBounds(351, 378, 143, 20);
		contentPane.add(txtCorreo);
		txtCorreo.setColumns(10);
	}
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnRegistrar) {
			actionPerformedBtnRegistrarJButton(arg0);
		}
	}
	protected void actionPerformedBtnRegistrarJButton(ActionEvent arg0) {
		String nom = txtNombre.getText().trim();
		String fec = txtFecha.getText().trim();
		String ruc  = txtRuc.getText().trim();
		String tar = txtTargeta.getText().trim();
		String cor = txtCorreo.getText().trim();
		
		if(nom.matches(Validaciones.NOMBRE) == false) {
			mensaje("El nombre es de 2 a 10 caracteres");
		}else if(fec.matches(Validaciones.FECHA_NACIMIENTO) == false) {
			mensaje("La fecha es YYYY-MM");
		}else if(ruc.matches(Validaciones.RUC) == false) {
			mensaje("El ruc es de formato 78XXXXXXXXX");
		}else if(tar.matches(Validaciones.TARGETA_CREDITO) == false) {
			mensaje("La targeta es de formato 15-203-XXXX-X");
		}else if(cor.matches(Validaciones.CORREO) == false) {
			mensaje("El correo es de formato c.XXXXXXX.XXX@telefonica.pe");
		}else {
			mensaje("Se env�an los datos");
		}
		
		
	}
	
	public void mensaje(String msg) {
		JOptionPane.showMessageDialog(this, msg);
	}
	
	
}




